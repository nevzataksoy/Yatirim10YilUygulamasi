from app.realtime.coinbase_orderbook import CoinbaseOrderBookWorker


def test_realtime_metrics_include_ofi_trade_imbalance_and_gap_count():
    worker = CoinbaseOrderBookWorker(products=("BTC-USD",), depth_levels=2)
    worker._on_message(None, '{"type":"snapshot","product_id":"BTC-USD","bids":[["100","2"],["99","1"]],"asks":[["101","1"],["102","2"]]}')
    worker._on_message(None, '{"type":"last_match","product_id":"BTC-USD","trade_id":10,"price":"100","size":"99","side":"sell"}')
    worker._on_message(None, '{"type":"l2update","product_id":"BTC-USD","changes":[["buy","100","3"],["sell","101","0.5"]]}')
    worker._on_message(None, '{"type":"match","product_id":"BTC-USD","trade_id":11,"price":"101","size":"2","side":"sell"}')
    worker._on_message(None, '{"type":"match","product_id":"BTC-USD","trade_id":13,"price":"100","size":"1","side":"buy"}')
    m = worker.metrics("BTC-USD")
    assert m is not None
    assert -1 <= m.ofi <= 1
    assert -1 <= m.trade_imbalance <= 1
    assert m.trade_notional_usd == 302
    assert m.trade_imbalance > 0
    assert m.trade_gap_count == 1
