from pathlib import Path
from app.engines.decision import DecisionEngine
from app.models import AppSettings, FactorScore

def test_decision_wait_on_low_quality(tmp_path: Path):
    defaults={"factor_weights":{"ETH/BTC":{"NEUTRAL":{"trend":1.0}}}}
    p=tmp_path/"d.json"; p.write_text(__import__('json').dumps(defaults))
    settings=AppSettings(supabase_host='x',supabase_user='x',supabase_password='x',alpha_vantage_api_key='x',fred_api_key='x',telegram_bot_token='x',telegram_chat_id='x',sec_user_agent='x@y.com')
    engine=DecisionEngine(settings,p)
    features={'ema_cross_age_bull':{'value':0},'rsi14':{'value':50},'bb_percent_b':{'value':0.5},'percentile_36m':{'value':0.2},'rv20':{'value':0.5},'rv60':{'value':0.5}}
    d,_=engine.build('ETH/BTC','2026-07-30','NEUTRAL',features,{'trend':FactorScore('trend',100,20)})
    assert d.status=='NO_ACTION_DATA'


def test_neutral_zero_score_does_not_vote_in_agreement(tmp_path: Path):
    defaults={"factor_weights":{"ETH/BTC":{"NEUTRAL":{"trend":0.4,"macro":0.4,"event":0.2}}}}
    p=tmp_path/"d2.json"; p.write_text(__import__('json').dumps(defaults))
    settings=AppSettings(supabase_host='x',supabase_user='x',supabase_password='x',alpha_vantage_api_key='x',fred_api_key='x',telegram_bot_token='x',telegram_chat_id='x',sec_user_agent='x@y.com')
    engine=DecisionEngine(settings,p)
    features={'ema_cross_age_bull':{'value':0},'rsi14':{'value':50},'bb_percent_b':{'value':0.5},'percentile_36m':{'value':0.5},'rv20':{'value':0.5},'rv60':{'value':0.5}}
    d,_=engine.build('ETH/BTC','2026-07-30','NEUTRAL',features,{
        'trend':FactorScore('trend',100,100),
        'macro':FactorScore('macro',-100,100),
        'event':FactorScore('event',0,100),
    })
    assert d.rationale['agreement'] == 0.0
