from app.collectors.alpha_vantage import AlphaVantageCollector


def test_alpha_vantage_retries_one_burst_limit(monkeypatch):
    collector = AlphaVantageCollector("x")
    responses = iter([
        {"Information": "Please spread out requests (1 request per second)."},
        {"Time Series (Daily)": {}},
    ])
    monkeypatch.setattr(collector, "_request_once", lambda *_: next(responses))
    monkeypatch.setattr("app.collectors.alpha_vantage.time.sleep", lambda *_: None)
    data = collector._request("TIME_SERIES_DAILY", "URA")
    assert "Time Series (Daily)" in data
