from app.engines.factors import score_derivatives


def test_deribit_inverse_perpetual_open_interest_is_already_usd():
    btc = {"venue":"deribit","funding_8h": 0, "basis_pct": 0, "open_interest": 100_000_000, "index_price": 60_000}
    eth = {"venue":"deribit","funding_8h": 0, "basis_pct": 0, "open_interest": 25_000_000, "index_price": 2_000}
    factor = score_derivatives(btc, eth)
    assert factor.details["btc_oi_usd"] == 100_000_000
    assert factor.details["eth_oi_usd"] == 25_000_000
    assert factor.details["oi_usd_ratio"] == 0.25


def test_derivatives_rejects_mixed_venues():
    btc = {"venue":"deribit","funding_8h": 0, "basis_pct": 0, "open_interest": 100}
    eth = {"venue":"okx","funding_8h": 0, "basis_pct": 0, "open_interest": 100}
    factor = score_derivatives(btc, eth)
    assert factor.quality == 0
    assert factor.details["missing"] is True
