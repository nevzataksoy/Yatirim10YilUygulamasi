from app.engines.factors import score_macro


def test_macro_old_observations_do_not_get_full_quality():
    rows = {
        "DGS2": {"value": 5.88, "observation_date": "1995-07-31"},
        "DGS10": {"value": 13.62, "observation_date": "1981-03-02"},
        "DFII10": {"value": -0.85, "observation_date": "2022-03-02"},
        "VIXCLS": {"value": 52.65, "observation_date": "2009-03-02"},
        "STLFSI4": {"value": -0.8263, "observation_date": "2026-07-24"},
        "DTWEXBGS": {"value": 128.28, "observation_date": "2025-02-28"},
        "NASDAQCOM": {"value": 433.42, "observation_date": "1990-04-05"},
        "SP500": {"value": 7316.15, "observation_date": "2026-07-29"},
    }
    factor = score_macro(rows, "2026-07-29")
    assert factor.quality == 25.0
    assert "DGS10" in factor.details["stale_or_missing"]
    assert factor.details["freshness_quality"]["SP500"] == 100.0
    assert factor.details["freshness_quality"]["STLFSI4"] == 100.0


def test_macro_recent_data_gets_high_quality():
    rows = {
        "DGS2": {"value": 4.31, "observation_date": "2026-07-28"},
        "DGS10": {"value": 4.71, "observation_date": "2026-07-28"},
        "DFII10": {"value": 2.43, "observation_date": "2026-07-28"},
        "VIXCLS": {"value": 17.0, "observation_date": "2026-07-28"},
        "STLFSI4": {"value": -0.8, "observation_date": "2026-07-24"},
        "DTWEXBGS": {"value": 120.5, "observation_date": "2026-07-25"},
        "NASDAQCOM": {"value": 23000, "observation_date": "2026-07-28"},
        "SP500": {"value": 7300, "observation_date": "2026-07-28"},
    }
    factor = score_macro(rows, "2026-07-29")
    assert factor.quality == 100.0
    assert not factor.details["stale_or_missing"]
