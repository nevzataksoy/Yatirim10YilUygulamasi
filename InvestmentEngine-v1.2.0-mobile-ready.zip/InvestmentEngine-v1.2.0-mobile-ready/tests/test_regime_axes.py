from app.engines.regime import detect_regime


def test_risk_on_macro_can_coexist_with_strong_downtrend_axis():
    features = {
        "ema21_slope_5d": {"value": -2.0},
        "rv20": {"value": 0.4},
        "rv60": {"value": 0.5},
    }
    regime, _, details = detect_regime(features, macro_score=15)
    assert regime == "RISK_ON_TREND"
    assert details["market_regime"] == "RISK_ON"
    assert details["trend_regime"] == "STRONG_DOWNTREND"
