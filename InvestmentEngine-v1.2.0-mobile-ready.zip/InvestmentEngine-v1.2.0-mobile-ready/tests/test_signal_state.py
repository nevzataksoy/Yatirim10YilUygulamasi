from app.engines.signal_state import apply_signal_state
from app.models import AppSettings, Decision


def settings():
    return AppSettings(
        base_tranche_pct=0.25,
        max_regime_pct=0.50,
        strong_action_edge=80,
        strong_action_confidence=80,
        regime_reset_edge=45,
        regime_reset_days=5,
    )


def decision(date, status="ACTION", direction="BTC→ETH", edge=75, confidence=75, size=0.25):
    return Decision(
        system="ETH/BTC", as_of=date, direction=direction, regime="NEUTRAL",
        edge_score=edge, confidence=confidence, uncertainty=100-confidence,
        data_quality=100, risk_score=20, recommended_size=size,
        late_entry=False, event_veto=False, status=status,
        execution_required=True, factors={}, rationale={},
    )


def test_action_is_staged_and_not_repeated_daily():
    cfg=settings(); state=None
    first=decision("2026-07-30")
    state=apply_signal_state(first,state,cfg)
    assert (first.action_event, first.action_stage, first.action_size, first.regime_cumulative_size)==(True,1,0.25,0.25)

    repeated=decision("2026-07-31")
    state=apply_signal_state(repeated,state,cfg)
    assert repeated.action_event is False
    assert repeated.action_stage==1 and repeated.regime_cumulative_size==0.25
    assert repeated.execution_required is False

    strong=decision("2026-08-01",edge=85,confidence=86)
    state=apply_signal_state(strong,state,cfg)
    assert (strong.action_event,strong.action_stage,strong.action_size,strong.regime_cumulative_size)==(True,2,0.25,0.50)

    after_max=decision("2026-08-02",edge=95,confidence=95)
    state=apply_signal_state(after_max,state,cfg)
    assert after_max.action_event is False
    assert after_max.action_stage==2 and after_max.regime_cumulative_size==0.50


def test_regime_resets_after_persistent_weakness():
    cfg=settings(); state=None
    state=apply_signal_state(decision("2026-07-30"),state,cfg)
    weak_dates=["2026-07-31","2026-08-01","2026-08-02","2026-08-03","2026-08-04"]
    for dt in weak_dates:
        state=apply_signal_state(decision(dt,status="WAIT",edge=40,confidence=40),state,cfg)
    assert state["stage"]==0 and state["active_direction"] is None

    renewed=decision("2026-08-05")
    state=apply_signal_state(renewed,state,cfg)
    assert renewed.action_event is True and renewed.action_stage==1
