from pathlib import Path

from app.backtest.validation import ReplayPoint, calibrate_edge_thresholds, classify_shadow_readiness


def _points(n: int = 180) -> list[ReplayPoint]:
    rows = []
    ratio = 0.03
    for i in range(n):
        ratio *= 1.0008
        active = i % 6 == 0
        rows.append(
            ReplayPoint(
                as_of=f"2026-01-{(i % 28) + 1:02d}",
                edge_signed=75.0 if active else 20.0,
                edge=75.0 if active else 20.0,
                confidence=70.0 if active else 40.0,
                data_quality=72.0,
                late_entry=False,
                regime="RISK_ON_TREND",
                ratio=ratio,
            )
        )
    return rows


def test_calibration_has_train_holdout_and_does_not_auto_apply():
    result = calibrate_edge_thresholds(_points())
    assert result["status"] in {"OK", "LIMITED_SIGNAL_COUNT"}
    assert result["candidates"]
    first = result["candidates"][0]
    assert "train" in first and "holdout" in first
    assert "auto" not in result
    assert "otomatik" in result["note"].lower()


def test_shadow_readiness_is_not_ready_during_observation_window():
    result = classify_shadow_readiness(
        {
            "calendar_days": 1,
            "crypto_decision_days": 1,
            "ura_decision_days": 1,
            "crypto_median_quality": 90,
            "ura_median_quality": 90,
            "job_count": 20,
            "job_success_rate": 1.0,
            "realtime_test_age_days": 0.1,
            "ura_holdings_dates": 1,
            "ura_breadth_dates": 1,
        }
    )
    assert result["status"] == "NOT_READY"
    assert result["waiting_reasons"]


def test_shadow_readiness_ready_when_all_gates_pass():
    result = classify_shadow_readiness(
        {
            "calendar_days": 35,
            "crypto_decision_days": 30,
            "ura_decision_days": 24,
            "crypto_median_quality": 91,
            "ura_median_quality": 86,
            "job_count": 100,
            "job_success_rate": 0.99,
            "realtime_test_age_days": 1,
            "ura_holdings_dates": 25,
            "ura_breadth_dates": 22,
        }
    )
    assert result["status"] == "READY"
    assert not result["waiting_reasons"]
    assert not result["blockers"]


def test_cli_wrappers_have_real_newlines_and_forward_args():
    root = Path(__file__).resolve().parents[1]
    cmd = (root / "InvestmentEngineCLI.cmd").read_text(encoding="utf-8")
    ps1 = (root / "InvestmentEngineCLI.ps1").read_text(encoding="utf-8")
    assert "\\n" not in cmd
    assert "\\n" not in ps1
    assert "%*" in cmd
    assert "ValueFromRemainingArguments" in ps1
    assert len(cmd.splitlines()) >= 5
