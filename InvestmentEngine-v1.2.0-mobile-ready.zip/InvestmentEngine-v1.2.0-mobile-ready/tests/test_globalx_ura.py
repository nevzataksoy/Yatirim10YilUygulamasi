from app.collectors.globalx_ura import GlobalXUraHoldingsCollector


def test_parse_globalx_holdings_skips_cash_and_normalizes_weight():
    text = """Global X Uranium ETF
Fund Holdings Data as of 07/29/2026
% of Net Assets,Ticker,Name,SEDOL,Market Price ($),Shares Held,Market Value ($)
23.52,CCO CN,CAMECO CORP,2166160,84.33,"14,495,909.00","1,222,489,525.90"
-0.01,,CASH,,1.0,"-327,655.84","-327,655.84"
5.49,OKLO,OKLO INC,BMD78K7,36.84,"7,745,966.00","285,361,387.44"
"""
    snapshot = GlobalXUraHoldingsCollector.parse_csv(text, "https://example/ura.csv")
    assert snapshot.holding_date == "2026-07-29"
    assert [h.ticker for h in snapshot.holdings] == ["CCO CN", "OKLO"]
    assert abs(snapshot.holdings[0].weight - 0.2352) < 1e-9
    assert snapshot.holdings[1].market_price == 36.84
