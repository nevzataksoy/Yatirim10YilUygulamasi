from app.security.cryptography_service import create_password_record, verify_password_record

def test_password_record():
    record=create_password_record("strong-pass-123")
    assert verify_password_record("strong-pass-123",record)
    assert not verify_password_record("wrong-password",record)
