import pytest

from app.collectors.derivatives import DerivativesCollector


class _Provider:
    def __init__(self, venue, fail=False):
        self.venue = venue
        self.fail = fail
        self.calls = []

    def fetch_snapshot(self, currency):
        self.calls.append(currency)
        if self.fail:
            raise RuntimeError(f"{self.venue} unavailable")
        return {
            "venue": self.venue,
            "currency": currency,
            "open_interest": 1,
        }


def test_auto_falls_back_as_complete_pair():
    deribit = _Provider("deribit", fail=True)
    okx = _Provider("okx")
    collector = DerivativesCollector(deribit=deribit, okx=okx)
    pair = collector.fetch_pair("auto")
    assert pair.provider == "okx"
    assert pair.fallback_used is True
    assert pair.btc["venue"] == pair.eth["venue"] == "okx"
    assert okx.calls == ["BTC", "ETH"]


def test_forced_provider_does_not_fallback():
    deribit = _Provider("deribit", fail=True)
    okx = _Provider("okx")
    collector = DerivativesCollector(deribit=deribit, okx=okx)
    with pytest.raises(RuntimeError):
        collector.fetch_pair("deribit")
    assert okx.calls == []
