from app.collectors.okx import OkxCollector


def test_okx_snapshot_uses_oi_usd_and_normalizes_funding(monkeypatch):
    collector = OkxCollector()

    def fake_one(path, **params):
        if path.endswith("open-interest"):
            return {"oiUsd": "2000000000", "oiCcy": "30000", "ts": "1785373839766"}
        if path.endswith("funding-rate"):
            return {
                "fundingRate": "0.00005",
                "premium": "0.0002",
                "fundingTime": "1785398400000",
                "nextFundingTime": "1785427200000",
                "ts": "1785373819071",
            }
        if path.endswith("market/ticker"):
            return {"last": "64000", "bidPx": "63999", "askPx": "64001", "ts": "1785373839000"}
        if path.endswith("mark-price"):
            return {"markPx": "64010", "ts": "1785373839000"}
        if path.endswith("index-tickers"):
            return {"idxPx": "64000", "ts": "1785373839000"}
        raise AssertionError(path)

    monkeypatch.setattr(collector, "_one", fake_one)
    row = collector.fetch_snapshot("BTC")
    assert row["venue"] == "okx"
    assert row["open_interest"] == 2_000_000_000
    assert row["funding_8h"] == 0.00005
    assert round(row["basis_pct"], 6) == round((64010 / 64000 - 1) * 100, 6)
