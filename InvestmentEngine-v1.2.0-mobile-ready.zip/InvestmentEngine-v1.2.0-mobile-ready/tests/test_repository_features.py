from app.database.feature_rows import build_feature_rows


def test_feature_rows_skip_as_of_metadata_and_non_numeric_values():
    rows = build_feature_rows(
        "ETH/BTC",
        "2026-07-29",
        {
            "ratio": {"value": 0.03, "quality": 100},
            "as_of": {"value": "2026-07-29", "quality": 100},
            "diagnostic": {"value": "not-a-number", "quality": 50},
        },
    )
    assert len(rows) == 1
    assert rows[0][2] == "ratio"
    assert rows[0][3] == 0.03
