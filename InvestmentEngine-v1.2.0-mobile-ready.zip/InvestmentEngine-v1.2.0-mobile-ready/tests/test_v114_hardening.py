from app.engines.ura import sec_monitor_quality_from_weight


def test_sec_quality_uses_fund_weight_and_cap():
    assert sec_monitor_quality_from_weight(0.0) == 0.0
    assert sec_monitor_quality_from_weight(0.2375) == 23.75
    assert sec_monitor_quality_from_weight(0.95) == 70.0
    assert sec_monitor_quality_from_weight(1.2) == 70.0


def test_cli_wrapper_replays_log_output():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    ps1 = (root / "InvestmentEngineCLI.ps1").read_text(encoding="utf-8")
    cmd = (root / "InvestmentEngineCLI.cmd").read_text(encoding="utf-8")
    assert "Select-Object -Skip $before" in ps1
    assert "Start-Process" in ps1 and "-Wait" in ps1
    assert "InvestmentEngineCLI.ps1" in cmd
