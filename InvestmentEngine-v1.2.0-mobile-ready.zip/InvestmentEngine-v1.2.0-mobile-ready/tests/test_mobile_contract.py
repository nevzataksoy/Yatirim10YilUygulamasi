from pathlib import Path

from app.models import AppSettings

ROOT = Path(__file__).resolve().parents[1]


def test_engine_settings_do_not_embed_mobile_public_keys():
    fields = set(AppSettings.__dataclass_fields__)
    assert "supabase_anon_key" not in fields
    assert "supabase_url" not in fields


def test_mobile_migration_has_auth_and_rls_contract():
    sql = (ROOT / "migrations" / "0003_mobile_api.sql").read_text(encoding="utf-8")
    for table in (
        "public.profiles",
        "public.investment_accounts",
        "public.portfolio_transactions",
        "public.user_investment_settings",
        "public.market_snapshot",
        "public.decision_snapshot",
        "public.decision_history",
        "public.engine_health_snapshot",
    ):
        assert table in sql
    assert "auth.uid() = user_id" in sql
    assert 'to authenticated' in sql
    assert 'revoke all on public.decision_snapshot from anon' in sql
    assert 'grant select on public.decision_snapshot to authenticated' in sql


def test_single_exe_build_and_installer_files_exist():
    assert (ROOT / "build.bat").is_file()
    assert (ROOT / "investmentengine_setup.iss").is_file()
    assert "--onefile" in (ROOT / "build.bat").read_text(encoding="utf-8")
    assert "--install-service" in (ROOT / "investmentengine_setup.iss").read_text(encoding="utf-8")
