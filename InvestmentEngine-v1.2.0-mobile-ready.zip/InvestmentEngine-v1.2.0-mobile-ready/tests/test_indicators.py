from app.features.technical import ema, rsi, macd, percentile_rank, zscore

def test_ema_and_macd_shapes():
    values=list(range(1,101)); assert len(ema(values,10))==100; m,s,h=macd(values); assert len(m)==len(s)==len(h)==100

def test_rsi_uptrend_high():
    values=[100+i for i in range(40)]; assert rsi(values,14)[-1] > 90

def test_percentile_and_zscore():
    assert percentile_rank([1,2,3,4],3)==0.75; assert zscore([1,2,3,4],2.5)==0
