from app.collectors.fred import FredCollector


class _Response:
    def raise_for_status(self):
        return None

    def json(self):
        # Simulate FRED descending response.
        return {
            "observations": [
                {"date": "2026-07-29", "value": "4.71", "realtime_start": "2026-07-30", "realtime_end": "2026-07-30"},
                {"date": "2026-07-28", "value": "4.69", "realtime_start": "2026-07-30", "realtime_end": "2026-07-30"},
            ]
        }


class _Session:
    def __init__(self):
        self.params = None

    def get(self, _url, params, timeout):
        self.params = params
        assert timeout == 30
        return _Response()


def test_fred_fetches_latest_desc_but_returns_chronological():
    collector = FredCollector("x")
    collector.session = _Session()
    rows = collector.fetch_series("DGS10", limit=1500)
    assert collector.session.params["sort_order"] == "desc"
    assert collector.session.params["limit"] == 1500
    assert [row["date"] for row in rows] == ["2026-07-28", "2026-07-29"]
