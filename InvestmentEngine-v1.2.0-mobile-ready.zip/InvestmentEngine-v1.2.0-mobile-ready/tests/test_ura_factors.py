from app.engines.ura import score_event_monitor, score_ura_breadth, score_ura_holdings_fundamentals


def test_missing_ura_factors_have_zero_quality():
    assert score_ura_holdings_fundamentals(None).quality == 0
    assert score_ura_breadth(None).quality == 0
    assert score_event_monitor(None, []).quality == 0


def test_single_holdings_snapshot_has_no_directional_quality():
    factor = score_ura_holdings_fundamentals({
        "current_date": "2026-07-29",
        "previous_date": None,
        "weight_coverage": 0.99,
        "constituents": 53,
    })
    assert factor.score == 0
    assert factor.quality == 0


def test_checked_quiet_event_monitor_is_neutral_but_quality_positive():
    factor = score_event_monitor({"status": "OK", "details": {"quality": 90}}, [])
    assert factor.score == 0
    assert factor.quality == 90


def test_event_monitor_preserves_explicit_zero_quality():
    factor = score_event_monitor(
        {"status": "DEGRADED", "details": {"quality": 0, "entities_checked": 0}},
        [],
    )
    assert factor.score == 0
    assert factor.quality == 0
    assert factor.details["missing"] is True
